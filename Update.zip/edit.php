<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    require 'db.php';
    $target_id=$_GET['id'];
    $data_select=mysqli_query($db,"SELECT * FROM `register_form` WHERE `id`='$target_id'");
    $data_row=mysqli_fetch_assoc($data_select);
    ?>
    <form action="" method="post"><br>
    <input type="text" name="sname" value="<?=$data_row['sname']?>" id=""><br>
    <input type="text" readonly name="username" value="<?=$data_row['username']?>" id=""><br>
    <input type="text" name="email" value="<?=$data_row['email']?>" id=""><br>
    <input type="text" name="mobile" value="<?=$data_row['mobile']?>" id=""><br>
    <input type="submit" value="Update" name="update">


    </form>
</body>
</html>
<?php  
if(isset($_POST['update'])){
    $sname=$_POST['sname'];
    $username=$_POST['username'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $update_query=mysqli_query($db,"UPDATE `register_form` SET `sname`='$sname',`username`='$username',`email`='$email',`mobile`='$mobile' WHERE `id`='$target_id'");
    if($update_query){
        echo '
        <script>
        alert("Successfully Updated data")
        window.location.href="index.php";
        </script>
        ';
    }
}
?>