<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="1" cellspacing="0">
        <tr>
            <td>Name</td>
            <td>Username</td>
            <td>Email</td>
            <td>Phone</td>
            <td>Edit</td>
            
        </tr>
            <?php
                require 'db.php';
            $select_data=mysqli_query($db,"SELECT * FROM `register_form`");
            while($rows=mysqli_fetch_assoc( $select_data)){
                ?>
                <tr>
            <td><?=$rows['sname']?></td>
            <td><?=$rows['username']?></td>
            <td><?=$rows['email']?></td>
            <td><?=$rows['mobile']?></td>
            <td><a onclick="return confirm('Are you sure? Edit this data!')" href="edit.php?id=<?=$rows['id']?>">Edit</a></td>
            </tr>
                <?php
            }
            
            ?>
    </table>
</body>
</html>