<?php 
    $db=mysqli_connect("localhost","root","","student_data");
 
?>